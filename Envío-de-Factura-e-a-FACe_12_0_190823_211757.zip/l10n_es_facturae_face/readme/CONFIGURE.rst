* Es necesario añadir el correo electrónico al que notificar los cambios de
  estado en la empresa
* Se debe configurar el servidor de envío
* Por defecto se añado el servicio web de test:
  https://se-face-webservice.redsara.es/facturasspp2
* Si queremos añadir el de producción, debemos cambiar el parámetro por
  https://webservice.face.gob.es/facturasspp2 y modificar el certificado en
  parámetros de sistema
