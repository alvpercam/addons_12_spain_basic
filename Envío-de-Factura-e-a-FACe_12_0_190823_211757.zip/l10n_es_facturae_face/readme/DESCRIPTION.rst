Este módulo permite la gestión del envío de la facturación electrónica española
a FACe.
La gestión del envío se realiza mediante los certificados con los que se firma.
